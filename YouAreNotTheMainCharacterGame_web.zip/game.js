
// Advanced 3-lane endless runner style demo with side-character support (Babylon.js)
const canvas = document.getElementById("renderCanvas");
const engine = new BABYLON.Engine(canvas, true, {preserveDrawingBuffer:true, stencil:true});
let scene, camera, light;
let player, hero;
let lanesX = [-3, 0, 3];
let playerLane = 1; // 0 left,1 center,2 right
let heroLane = 1;
let obstacles = []; // {type, lane, z, mesh, helped}
let running = false;
let distance = 0;
let helps = 0;
let heroHealth = 3;
const statusTxt = document.getElementById("statustxt");
const helpsTxt = document.getElementById("helps");
const distTxt = document.getElementById("distance");
const hHealthTxt = document.getElementById("hhealth");
const startBtn = document.getElementById("startBtn");

startBtn.addEventListener("click", ()=>{ if(!running){ startGame(); }} );

function createScene() {
    scene = new BABYLON.Scene(engine);
    scene.clearColor = new BABYLON.Color3(0.12,0.14,0.18);

    camera = new BABYLON.UniversalCamera("cam", new BABYLON.Vector3(0,6,-12), scene);
    camera.setTarget(BABYLON.Vector3.Zero());
    camera.attachControl(canvas, true);

    light = new BABYLON.HemisphericLight("h", new BABYLON.Vector3(0,1,0), scene);
    light.intensity = 0.95;

    // Ground and track visuals
    const ground = BABYLON.MeshBuilder.CreateGround("ground", {width: 30, height: 1000}, scene);
    const gmat = new BABYLON.StandardMaterial("gmat", scene);
    gmat.diffuseColor = new BABYLON.Color3(0.18,0.16,0.12);
    ground.material = gmat;
    ground.position.z = 100;

    // lanes lines
    for(let i= -50; i<1000; i+=5){
        const line = BABYLON.MeshBuilder.CreateBox("line"+i,{size:0.15},scene);
        line.scaling.z = 2;
        line.position = new BABYLON.Vector3(0,0.05,i);
        const lmat = new BABYLON.StandardMaterial("lmat",scene);
        lmat.emissiveColor = new BABYLON.Color3(0.5,0.5,0.5);
        line.material = lmat;
    }

    // Player (side character) - blue
    player = BABYLON.MeshBuilder.CreateBox("player",{size:1},scene);
    player.position = new BABYLON.Vector3(lanesX[playerLane],0.5,0);
    const pmat = new BABYLON.StandardMaterial("pmat",scene);
    pmat.diffuseColor = new BABYLON.Color3(0.1,0.6,1);
    player.material = pmat;

    // Hero (main character) - red, auto-running at fixed lane (hero may change lane slightly)
    hero = BABYLON.MeshBuilder.CreateBox("hero",{size:1.2},scene);
    hero.position = new BABYLON.Vector3(lanesX[heroLane],0.6,-10);
    const hmat = new BABYLON.StandardMaterial("hmat",scene);
    hmat.diffuseColor = new BABYLON.Color3(0.8,0.15,0.15);
    hero.material = hmat;
    hero.health = heroHealth;

    // GUI text on hero
    const gui = BABYLON.GUI.AdvancedDynamicTexture.CreateFullscreenUI("UI");
    const heroLabel = new BABYLON.GUI.TextBlock();
    heroLabel.text = "Hero";
    heroLabel.color = "white";
    heroLabel.fontSize = 14;
    heroLabel.linkOffsetY = -80;
    gui.addControl(heroLabel);
    heroLabel.linkWithMesh(hero);

    // initial obstacles
    for(let z=20; z<200; z+=12){
        maybeSpawnObstacle(z);
    }

    setupControls();
    return scene;
}

function maybeSpawnObstacle(z) {
    if(Math.random() < 0.6){
        const lane = Math.floor(Math.random()*3);
        const type = (Math.random() < 0.5) ? "pit" : "rock";
        spawnObstacle(type, lane, z);
    }
}

function spawnObstacle(type, lane, z) {
    let mesh;
    if(type === "pit"){
        mesh = BABYLON.MeshBuilder.CreateBox("pit"+z,{width:2.8, height:0.1, depth:6}, scene);
        mesh.position = new BABYLON.Vector3(lanesX[lane], 0.05, z);
        const m = new BABYLON.StandardMaterial("m", scene); m.diffuseColor = new BABYLON.Color3(0.05,0.05,0.08);
        mesh.material = m;
    } else if(type === "rock"){
        mesh = BABYLON.MeshBuilder.CreateBox("rock"+z,{size:1.6}, scene);
        mesh.position = new BABYLON.Vector3(lanesX[lane], 0.8, z);
        const m = new BABYLON.StandardMaterial("m2", scene); m.diffuseColor = new BABYLON.Color3(0.25,0.2,0.18);
        mesh.material = m;
    }
    obstacles.push({type, lane, z, mesh, helped:false, handled:false});
}

// Controls: A/D to change lane, W to dash forward; R/M/P to help
let input = {};
function setupControls(){
    window.addEventListener("keydown", (e)=>{ input[e.key.toLowerCase()] = true; });
    window.addEventListener("keyup", (e)=>{ input[e.key.toLowerCase()] = false; });
}

function startGame(){
    running = true;
    startBtn.style.display = "none";
    statusTxt.innerText = "Playing";
    distance = 0;
    helps = 0;
    hero.health = heroHealth;
    helpsTxt.innerText = helps;
    distTxt.innerText = distance;
    hHealthTxt.innerText = hero.health;
}

function gameOver(win){
    running = false;
    statusTxt.innerText = win ? "Hero escaped! You win!" : "Hero failed. Game Over.";
    startBtn.innerText = "Restart";
    startBtn.style.display = "inline-block";
}

// main loop
scene = createScene();
engine.runRenderLoop(()=>{
    const delta = engine.getDeltaTime();
    if(!running){
        scene.render();
        return;
    }
    const speed = 0.03 * delta * (1 + distance/1000); // speed increases with distance
    // Update hero forward
    hero.position.z += speed * 0.7;
    // Update player input: lane change
    if(input["a"] && playerLane > 0){ playerLane--; input["a"]=false; }
    if(input["d"] && playerLane < 2){ playerLane++; input["d"]=false; }
    // smooth lane transition for player
    player.position.x += (lanesX[playerLane] - player.position.x) * 0.25;

    // dash forward (move player closer to hero)
    if(input["w"]) player.position.z += 0.08 * delta;

    // camera follows between player and hero for cinematic effect
    const camTargetZ = (player.position.z + hero.position.z)/2;
    camera.position.z = camTargetZ - 12;
    camera.position.x = player.position.x;
    camera.target = new BABYLON.Vector3(player.position.x, 0.6, camTargetZ+6);

    // spawn new obstacles ahead
    if(obstacles.length < 40){
        const lastZ = obstacles.length ? obstacles[obstacles.length-1].z : hero.position.z + 30;
        maybeSpawnObstacle(lastZ + 12 + Math.random()*8);
    }

    // check hero interactions with nearest obstacle
    for(let obs of obstacles){
        if(obs.handled) continue;
        const dz = obs.z - hero.position.z;
        if(dz < 1.2 && dz > -0.8){
            // hero reaches obstacle now
            if(obs.type === "pit"){
                if(obs.helped){
                    // filled => pass
                    obs.handled = true;
                    if(obs.mesh) obs.mesh.dispose();
                } else {
                    // hero falls -> game over
                    obs.handled = true;
                    statusTxt.innerText = "Hero fell in a pit!";
                    gameOver(false);
                }
            } else if(obs.type === "rock"){
                if(obs.helped){
                    // pushed => pass
                    if(obs.mesh) obs.mesh.dispose();
                    obs.handled = true;
                } else {
                    // hero collides -> lose health
                    obs.handled = true;
                    hero.health -= 1;
                    hHealthTxt.innerText = hero.health;
                    statusTxt.innerText = "Hero hit a rock! Health: " + hero.health;
                    if(hero.health <= 0){ gameOver(false); }
                    if(obs.mesh) obs.mesh.dispose();
                }
            }
        }
    }

    // Player help actions
    if(input["r"]){ // throw rope to help pit or make hero jump
        handleHelpAction("rope");
        input["r"] = false;
    }
    if(input["m"]){ // fill pit with mud
        handleHelpAction("mud");
        input["m"] = false;
    }
    if(input["p"]){ // push rock
        handleHelpAction("push");
        input["p"] = false;
    }

    // update distance
    distance += speed * 0.02;
    distTxt.innerText = Math.floor(distance);

    scene.render();
});

// help logic: find nearest obstacle in hero's lane within 8 units ahead and apply appropriate help
function handleHelpAction(action){
    if(!running) return;
    // find nearest obstacle in hero's lane within z range
    let target = null;
    for(let obs of obstacles){
        if(obs.lane !== heroLane) continue;
        if(obs.handled) continue;
        const dz = obs.z - hero.position.z;
        if(dz > 0 && dz < 8){
            target = obs;
            break;
        }
    }
    if(!target){
        statusTxt.innerText = "No immediate obstacle to help.";
        return;
    }
    // require player to be near hero (z difference small) OR allow action if within distance
    const playerDist = Math.abs(player.position.z - hero.position.z);
    if(playerDist > 12){
        statusTxt.innerText = "Too far from hero to help. Move closer.";
        return;
    }
    // handle based on obstacle type and action mapping
    if(target.type === "pit"){
        if(action === "mud" || action === "rope"){
            // fill pit by placing a filler
            const filler = BABYLON.MeshBuilder.CreateBox("filler"+target.z,{width:2.8, height:0.6, depth:6}, scene);
            filler.position = new BABYLON.Vector3(lanesX[target.lane], 0.3, target.z);
            const fm = new BABYLON.StandardMaterial("fm", scene);
            fm.diffuseColor = new BABYLON.Color3(0.55,0.45,0.25);
            filler.material = fm;
            target.helped = true;
            helps++;
            helpsTxt.innerText = helps;
            statusTxt.innerText = "You filled the pit! Hero can pass.";
        } else {
            statusTxt.innerText = "That won't help a pit.";
        }
    } else if(target.type === "rock"){
        if(action === "push"){
            // simulate pushing by animating the rock away
            if(target.mesh){
                const anim = new BABYLON.Animation("pushAnim","position.x",60,BABYLON.Animation.ANIMATIONTYPE_FLOAT,BABYLON.Animation.ANIMATIONLOOPMODE_CONSTANT);
                const keys = []; keys.push({frame:0,value:lanesX[target.lane]}); keys.push({frame:30,value:lanesX[target.lane]+6});
                anim.setKeys(keys);
                target.mesh.animations = []; target.mesh.animations.push(anim);
                scene.beginAnimation(target.mesh,0,30,false);
            }
            target.helped = true;
            helps++;
            helpsTxt.innerText = helps;
            statusTxt.innerText = "You pushed the rock away!";
        } else {
            statusTxt.innerText = "Can't fill rock with mud. Try pushing (P).";
        }
    }
}
