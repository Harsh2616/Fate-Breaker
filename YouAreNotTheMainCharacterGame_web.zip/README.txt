YouAreNotTheMainCharacterGame - Web (Babylon.js)
--------------------------------------------------
This package provides a browser-playable 3D endless-runner style demo where you are the side character.
It is NOT a Unity WebGL build. Instead, it follows the folder structure you requested but uses Babylon.js so you can run the game by simply opening index.html.

How to run:
1. Unzip the package.
2. Open index.html in a modern browser (Chrome/Edge/Firefox).
   - If the game doesn't run due to browser restrictions, run a local server:
     python -m http.server 8000
     and open http://localhost:8000/index.html
Controls:
 - Change lane: A / D
 - Dash forward: W
 - Help actions: R (rope), M (mud/fill pit), P (push rock)
 - Start / Restart: Start button in UI
Notes:
 - The Build/ and TemplateData/ folders are placeholders to match the Unity WebGL structure you requested.
 - If you want a true Unity WebGL build (exported binaries), I can provide a Unity project zip that you open in Unity Editor and then build WebGL locally on your machine.
